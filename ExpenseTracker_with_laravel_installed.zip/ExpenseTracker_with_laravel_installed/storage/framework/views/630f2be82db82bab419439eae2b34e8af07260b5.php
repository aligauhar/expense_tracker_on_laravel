
<?php $__env->startSection('content'); ?>
    <h1>Products here</h1>
    <br><br>
    <div class="row row-cols-1 row-cols-md-2">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col mb-4">
                <div class="card">
                <img  style="width: 460px; height: 404px; margin-left:15%;" src="<?php echo e(asset('img/' . $item->img . '.PNG')); ?>" class="card-img-top" alt="...">
                 <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                        <p class="card-text"><?php echo e($item->discription); ?></p>
                        <h5 class="card-title">Price: <?php echo e($item->price); ?>$</h5>
                        <?php if(session('role') == 'Admin'): ?>
                            <a href="/delete/<?php echo e($item->id); ?>"> <i class="fa fa-trash">delete</i> </a>
                            <a href="/edit/<?php echo e($item->id); ?>"> <i class="fa fa-edit">edit</i> </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprj\resources\views/list.blade.php ENDPATH**/ ?>