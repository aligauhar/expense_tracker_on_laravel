
<?php $__env->startSection('content'); ?>
<h1>Register page here</h1>
<form method="post" action="register" >
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label >Name</label>
    <input type="text" name="username" class="form-control"  placeholder = "Enter name">
  </div>
  <div class="form-group">
    <label >Password</label>
    <input type="password" name="password" class="form-control"  placeholder = "Enter password">
  </div>
  <div class="form-group">
    <label >Role</label>
    <input type="text" name="role" class="form-control"  placeholder = "Enter role">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprj\resources\views/register.blade.php ENDPATH**/ ?>