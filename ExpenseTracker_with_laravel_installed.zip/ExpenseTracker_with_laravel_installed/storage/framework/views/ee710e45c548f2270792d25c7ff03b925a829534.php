
<?php $__env->startSection('content'); ?>
<div class="col-sm-6" >
<form method="post" action="" >
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label >Product Name</label>
    <input type="text" name="name" class="form-control"  placeholder = "Enter name">
  </div>
  <div class="form-group">
    <label >Discription</label>
    <input type="text" name="discription" class="form-control"  placeholder = "Enter discription">
  </div>
  <div class="form-group">
    <label >price</label>
    <input type="number" name="price" class="form-control"  placeholder = "Enter price">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprj\resources\views/add.blade.php ENDPATH**/ ?>