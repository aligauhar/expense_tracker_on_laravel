
<?php $__env->startSection('content'); ?>
<div class="col-sm-6" >
    <h1>Edit product</h1>
<form method="post" action="/edit" >
<?php echo csrf_field(); ?>
  <div class="form-group">
  <input type="hidden" name="id" value="<?php echo e($data->id); ?>" >
 
    <label >Product Name</label>
    <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control"  placeholder = "Enter name">
  </div>
  <div class="form-group">
    <label >Discription</label>
    <input type="text" name="discription" value="<?php echo e($data->discription); ?>" class="form-control"  placeholder = "Enter discription">
  </div>
  <div class="form-group">
    <label >price</label>
    <input type="number" name="price" value="<?php echo e($data->price); ?>" class="form-control"  placeholder = "Enter price">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprj\resources\views/edit.blade.php ENDPATH**/ ?>